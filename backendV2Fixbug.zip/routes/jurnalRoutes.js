const express = require('express')
const {getSaldoDanDebit,crateJurnal,getJurnal}= require('../controller/jurnalAkutansiController')
const {verifyUser,superAdminOnly} = require('../middleware/userMiddleware')
const router = express.Router()

router.get('/getsaldodandebit',verifyUser,superAdminOnly,getSaldoDanDebit)
router.get('/getjurnal',verifyUser,superAdminOnly,getJurnal)
router.post('/createjurnal',verifyUser,superAdminOnly,crateJurnal)

module.exports = router

