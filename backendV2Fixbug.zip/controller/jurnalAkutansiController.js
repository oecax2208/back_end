const jurnalAkuntansi = require('../models/jurnalAkutansiModel')
const Wearhouse = require('../models/wearhouseModel')
const mutasiStok = require('../models/mutasiStokModel')
const { Op, literal, fn, col } = require("sequelize");
const Transaksi = require('../models/transaksiModel');
const TransaksiDetail = require('../models/transaksiDetailModel');
const MutasiStok = require('../models/mutasiStokModel');
const DistribusiStok = require('../models/distribusiStokModel');
const Barang = require('../models/barangModel');
const BarangCabang = require('../models/BarangCabang');
const Cabang = require('../models/cabangModel');
const db = require('../config/database');
exports.getSaldoDanDebit = async (req, res) => {
    try {
        const { bulan, tahun } = req.query;

        if (!bulan || !tahun) {
            return res.status(400).json({ message: "Bulan dan tahun harus disertakan." });
        }

        const bulanSebelumnya = bulan - 1;
        const tahunSebelumnya = bulanSebelumnya === 0 ? tahun - 1 : tahun;
        const bulanSebelumnyaFix = bulanSebelumnya === 0 ? 12 : bulanSebelumnya;

        // Ambil awal dan akhir bulan
        const startDate = new Date(tahun, bulan - 1, 1);
        const endDate = new Date(tahun, bulan, 0); // Hari terakhir bulan

        // Ambil saldo terakhir bulan sebelumnya
        const lastMonthTransaction = await jurnalAkuntansi.findOne({
            where: {
                createdAt: {
                    [Op.between]: [
                        new Date(tahunSebelumnya, bulanSebelumnyaFix - 1, 1),
                        new Date(tahunSebelumnya, bulanSebelumnyaFix, 0)
                    ]
                }
            },
            order: [['createdAt', 'DESC']],
            attributes: ['saldo'],
            raw: true
        });

        const saldoBulanSebelumnya = lastMonthTransaction ? parseFloat(lastMonthTransaction.saldo) : 0;

        // Ambil total pemasukan (kredit) dan pengeluaran (debit) bulan ini
        const result = await jurnalAkuntansi.findAll({
            where: {
                createdAt: {
                    [Op.between]: [startDate, endDate]
                }
            },
            attributes: [
                [fn('SUM', col('debit')), 'total_debit'],
                [fn('SUM', col('kredit')), 'total_kredit'],
                [literal('SUM(kredit) - SUM(debit)'), 'saldo_berjalan']
            ],
            raw: true
        });

        const totalDebit = parseFloat(result[0].total_debit || 0);
        const totalKredit = parseFloat(result[0].total_kredit || 0);
        const saldoBerjalan = totalKredit - totalDebit;

        // Saldo akhir = saldo bulan sebelumnya + saldo berjalan
        const saldoAkhir = saldoBulanSebelumnya + saldoBerjalan;

        return res.json({
            bulan,
            tahun,
            total_pengeluaran: totalDebit.toFixed(2),
            total_pemasukan: totalKredit.toFixed(2),
            saldo_berjalan: saldoBerjalan.toFixed(2),
            saldo_akhir: saldoAkhir.toFixed(2)
        });

    } catch (error) {
        console.error("Error in getSaldoDanDebit:", error);
        return res.status(500).json({ 
            message: "Terjadi kesalahan pada server.",
            error: error.message 
        });
    }
};

exports.getJurnal = async (req, res) => {
    try {
        const { start_date, end_date, jenis_transaksi } = req.query;
        
        let whereClause = {};
        
        // Filter berdasarkan tanggal jika ada
        if (start_date && end_date) {
            whereClause.createdAt = {
                [Op.between]: [new Date(start_date), new Date(end_date)]
            };
        }
        
        // Filter berdasarkan jenis transaksi jika ada
        if (jenis_transaksi) {
            whereClause.jenis_transaksi = jenis_transaksi;
        }

        const jurnal = await jurnalAkuntansi.findAll({
            where: whereClause,
            include: [
                {
                    model: Barang,
                    attributes: ['namabarang', 'harga']
                },
                {
                    model: Cabang,
                    attributes: ['namacabang']
                }
            ],
            order: [['createdAt', 'DESC']]
        });

        if (!jurnal.length) {
            return res.status(404).json({ 
                message: "Data jurnal tidak ditemukan.",
                data: [] 
            });
        }

        return res.status(200).json({
            message: "Data jurnal berhasil ditemukan",
            data: jurnal
        });
        
    } catch (error) {
        console.error('Error in getJurnal:', error);
        return res.status(500).json({ 
            message: "Terjadi kesalahan pada server.",
            error: error.message 
        });
    }
};

exports.crateJurnal = async (req, res) => {
    const transaction = await db.transaction();
    try {
        const { cabanguuid, jenis_transaksi, baranguuid, jumlah, harga_satuan, deskripsi } = req.body;

        const total_harga = jumlah * harga_satuan;
        const debit = jenis_transaksi === 'pembelian' ? total_harga : 0;
        const kredit = jenis_transaksi === 'penjualan' ? total_harga : 0;
        const jurnalEntry = await jurnalAkuntansi.create({
            cabanguuid,
            jenis_transaksi,
            baranguuid,
            deskripsi,
            debit,
            kredit,
            saldo: 0,
            jumlah,
            harga_satuan,
            total_harga
        }, { transaction });

        if (jenis_transaksi === 'pembelian') {
            let wearhouseEntry = await Wearhouse.findOne({ where: { baranguuid }, transaction });

            if (wearhouseEntry) {
                wearhouseEntry.stok_gudang = Number(wearhouseEntry.stok_gudang) + Number(jumlah);
                await wearhouseEntry.save({ transaction });
            } else {
                wearhouseEntry = await Wearhouse.create({
                    baranguuid,
                    stok_gudang: Number(jumlah)
                }, { transaction });
            }

            await mutasiStok.create({
                baranguuid,
                cabanguuid: null, 
                jenis_mutasi: 'masuk',
                jumlah,
                keterangan: `Pembelian barang masuk ke gudang (${deskripsi})`
            }, { transaction });
        }

        await transaction.commit();
        return res.status(201).json({ message: 'Jurnal berhasil dibuat', data: jurnalEntry });

    } catch (error) {
        await transaction.rollback();
        console.error(error);
        return res.status(500).json({ message: 'Terjadi kesalahan pada server' });
    }
};
